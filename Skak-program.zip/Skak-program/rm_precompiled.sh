cd chess_algorithm
rm **/*.hpp.gch
rm *.o

cd ../chess_lib
rm **/*.hpp.gch
rm *.o

cd ../PC_Chess_IO
rm **/*.hpp.gch
rm *.o