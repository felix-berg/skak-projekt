#ifndef STEPPER_HPP
#define STEPPER_HPP

int num_pulses = 0;

class Stepper {
public:
  static const long time_until_sleep = 500000 ;
  static const int min_pulse_time = 385; // measured with no load

   Stepper(int dir, int stepp, int sleep, int steps_per_resolution, int steps_per_second)
      :  dir_pin { dir }, step_pin { stepp }, sleep_pin { sleep }, m_total_steps { steps_per_resolution } { 
          set_speed(steps_per_second);
      };

   void init();
   void update();

   /* Set target */
   void step_to(int step) { m_target_step = step; };

   /* Shift target */
   void move_target(int steps) { m_target_step += steps; };

   /* Step number of steps. */ 
   void step(int steps) { m_target_step = m_current_step + steps; };

   /* Returns number of steps per round. */
   int total_steps() const { return m_total_steps; };

   /* Returns the current position. */ 
   int current_step() const { return m_current_step; };
   
  void set_speed(int steps_per_sec) { m_pulse_time = 500000 / steps_per_sec; }; // integer division -> floor value
  void set_step_time(int t) { m_pulse_time = t / 2; };

  int sleep() { set_sleep(true ); };
  int wake()  { set_sleep(false); };

protected:
   void pulse();
   /* Set direction */
   void dir(bool d) { 
      if (m_direction == d)
         return;
      
      m_direction = d; 
      digitalWrite(dir_pin, m_direction);
   };	

   /* Set state of sleep pin */
   void set_sleep(bool s) {
    digitalWrite(sleep_pin, HIGH);
    
      if (m_sleep == s)
         return;    
    
      m_sleep = s; 
      digitalWrite(sleep_pin, !m_sleep);
   }

   int step_pin, dir_pin, sleep_pin;
   int m_total_steps = 0;
   int m_target_step = 0;

   int m_pulse_time; // time in µs of half a step-time

private:
   bool m_pinstate = false;
   bool m_direction = true;
   bool m_sleep = true;
   unsigned long m_last_pulse;

   int m_current_step = 0;
};

/** To be called in the arduino setup() function. */
void Stepper::init() {
   // initiate pin outputs
   pinMode(step_pin, OUTPUT);
   pinMode(dir_pin,  OUTPUT);
   pinMode(sleep_pin, OUTPUT);

   // set default values to pins
   digitalWrite(dir_pin, m_direction);
   digitalWrite(step_pin, m_pinstate);

  set_sleep(false);
  
  m_last_pulse = micros();
}

/*
   Continue the stepping by doing a pulse.
   Should be called every half step-time. (m_pulse_time)
*/
void Stepper::pulse() {
   // switch step pin
   m_pinstate = !m_pinstate;
   digitalWrite(step_pin, m_pinstate);

   if (!m_pinstate) { // if this was a falling pulse, a step is done
      m_current_step += int(m_direction) * 2 - 1; // set to -1 or 1 depending on m_direction.
   }
}
/*
   Should be called in the arduino update() function.
   Steps the motor, if the given pulse-time has passed.
   Deals with m_current_step.
*/
void Stepper::update() {
   bool should_move = m_current_step != m_target_step;

   if (should_move) { /* Move towards target */
    set_sleep(false);
    
      bool target_dir = m_target_step > m_current_step;
   
      if (target_dir != m_direction) {
        // if the direction is incorrect.
      dir(target_dir); // set the direction of the step
      }
         

      // if enough time has passed since the last pulse
      if (micros() - m_last_pulse > m_pulse_time) {
         pulse();
         // reset timer by adding the waited time
         m_last_pulse = micros(); 
      }
   }

  if (!should_move && m_pinstate) {
    if (micros() - m_last_pulse > m_pulse_time) {
      pulse();
      // reset timer by adding the waited time
      m_last_pulse += m_pulse_time; 
    }
  }

  if (micros() - m_last_pulse > time_until_sleep)
    set_sleep(false);

}

#endif
